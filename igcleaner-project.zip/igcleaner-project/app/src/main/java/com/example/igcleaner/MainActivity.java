package com.example.igcleaner;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(40, 80, 40, 40);

        Button a = new Button(this);
        a.setText("1) تفعيل الخدمة");
        a.setOnClickListener(v ->
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        Button d = new Button(this);
        d.setText("3) سجّل الشاشة");
        d.setOnClickListener(v -> {
            if (CleanerService.instance == null) {
                Toast.makeText(this, "فعّل الخدمة أول", Toast.LENGTH_LONG).show();
                return;
            }
            CleanerService.dump();
            Toast.makeText(this, "افتح المحادثة بانستكرام، عندك 5 ثواني", Toast.LENGTH_LONG).show();
        });

        Button s = new Button(this);
        s.setText("2) ابدأ (افتح محادثة انستكرام بعدها)");
        s.setOnClickListener(v -> {
            if (CleanerService.instance == null) {
                Toast.makeText(this, "فعّل الخدمة أول", Toast.LENGTH_LONG).show();
                return;
            }
            CleanerService.start();
            Toast.makeText(this, "يبدأ بعد 5 ثواني، افتح المحادثة", Toast.LENGTH_LONG).show();
        });

        Button x = new Button(this);
        x.setText("إيقاف");
        x.setOnClickListener(v -> CleanerService.running = false);

        l.addView(a);
        l.addView(s);
        l.addView(d);
        l.addView(x);
        setContentView(l);
    }
}
