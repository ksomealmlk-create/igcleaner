package com.example.igcleaner;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.Toast;

public class CleanerService extends AccessibilityService {
    static CleanerService instance;
    static volatile boolean running = false;

    final Handler h = new Handler(Looper.getMainLooper());
    int misses = 0, longTries = 0;
    int screenW, screenH;

    // الكلمات اللي يضغطها (القائمة + التأكيد + نافذة "موافق")
    static final String[] UNSEND = {"Unsend", "إلغاء الإرسال", "إلغاء إرسال", "Unsend message", "موافق", "OK"};

    final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            try { step(); } catch (Exception ignored) {}
            h.postDelayed(this, 2000); // التأخير بين كل خطوة
        }
    };

    static void start() {
        CleanerService s = instance;
        s.misses = 0;
        s.longTries = 0;
        running = true;
        s.h.removeCallbacksAndMessages(null);
        s.h.postDelayed(s.tick, 5000);
    }

    @Override protected void onServiceConnected() {
        instance = this;
        DisplayMetrics m = getResources().getDisplayMetrics();
        screenW = m.widthPixels;
        screenH = m.heightPixels;
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}

    @Override public boolean onUnbind(android.content.Intent i) {
        instance = null;
        running = false;
        return super.onUnbind(i);
    }

    void step() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        if (!"com.instagram.android".equals(String.valueOf(root.getPackageName()))) return;

        // 1) زر Unsend / موافق ظاهر؟ اضغطه
        AccessibilityNodeInfo u = findByText(root, UNSEND);
        if (u != null) {
            clickNode(u);
            longTries = 0;
            misses = 0;
            return;
        }

        // 2) دور على آخر رسالة إلك
        AccessibilityNodeInfo msg = null;
        if (longTries < 3) msg = findOwnMessage(root);
        if (msg != null) {
            Rect r = new Rect();
            msg.getBoundsInScreen(r);
            longPress(r.centerX(), r.centerY());
            longTries++;
            return;
        }

        // 3) ما لقينا شي: انزل للرسايل القديمة
        longTries = 0;
        AccessibilityNodeInfo sc = findScrollable(root);
        if (sc != null) sc.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
        misses++;
        if (misses > 8) {
            running = false;
            Toast.makeText(this, "خلص أو ما لقيت رسائل", Toast.LENGTH_LONG).show();
        }
    }

    AccessibilityNodeInfo best;
    int bestBottom;

    AccessibilityNodeInfo findOwnMessage(AccessibilityNodeInfo root) {
        best = null;
        bestBottom = -1;
        scanOwn(root);
        return best;
    }

    void scanOwn(AccessibilityNodeInfo n) {
        if (n == null) return;
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        CharSequence t = n.getText() != null ? n.getText() : n.getContentDescription();
        boolean isEdit = "android.widget.EditText".contentEquals(String.valueOf(n.getClassName()));
        // الواجهة عربية (RTL): رسائلك على اليسار
        if (t != null && t.length() > 0 && !isEdit && n.getChildCount() == 0
                && r.left <= screenW * 0.15 && r.right < screenW * 0.85
                && r.top > 250 && r.bottom < screenH - 300
                && r.bottom > bestBottom) {
            best = n;
            bestBottom = r.bottom;
        }
        for (int i = 0; i < n.getChildCount(); i++) scanOwn(n.getChild(i));
    }

    AccessibilityNodeInfo findByText(AccessibilityNodeInfo root, String[] words) {
        for (String w : words) {
            java.util.List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(w);
            if (l != null) {
                for (AccessibilityNodeInfo n : l) {
                    CharSequence t = n.getText();
                    if (t != null && t.toString().trim().equalsIgnoreCase(w)) return n;
                }
            }
        }
        return null;
    }

    AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n) {
        if (n == null) return null;
        if (n.isScrollable()) return n;
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findScrollable(n.getChild(i));
            if (r != null) return r;
        }
        return null;
    }

    void clickNode(AccessibilityNodeInfo n) {
        AccessibilityNodeInfo p = n;
        while (p != null && !p.isClickable()) p = p.getParent();
        if (p != null && p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return;
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        gesture(r.centerX(), r.centerY(), 50);
    }

    void longPress(int x, int y) { gesture(x, y, 700); }

    void gesture(int x, int y, long dur) {
        Path p = new Path();
        p.moveTo(x, y);
        GestureDescription.Builder b = new GestureDescription.Builder();
        b.addStroke(new GestureDescription.StrokeDescription(p, 0, dur));
        dispatchGesture(b.build(), null, null);
    }

    // ---------- تسجيل الشاشة (للتشخيص) ----------
    static void dump() {
        final CleanerService s = instance;
        s.h.postDelayed(new Runnable() {
            @Override public void run() { s.doDump(); }
        }, 5000);
    }

    void doDump() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) {
            Toast.makeText(this, "ما شفت الشاشة", Toast.LENGTH_LONG).show();
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("screen ").append(screenW).append("x").append(screenH).append("\n");
        walk(root, 0, sb);
        android.content.ClipboardManager cm =
            (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        cm.setPrimaryClip(android.content.ClipData.newPlainText("dump", sb.toString()));
        Toast.makeText(this, "انسخت! الصقها بالدردشة", Toast.LENGTH_LONG).show();
    }

    void walk(AccessibilityNodeInfo n, int depth, StringBuilder sb) {
        if (n == null) return;
        Rect r = new Rect();
        n.getBoundsInScreen(r);
        for (int i = 0; i < depth; i++) sb.append(" ");
        sb.append(n.getClassName())
          .append(" | ").append(n.getText())
          .append(" | ").append(n.getContentDescription())
          .append(" | ").append(r.left).append(",").append(r.top)
          .append(",").append(r.right).append(",").append(r.bottom)
          .append(" | click=").append(n.isClickable())
          .append("\n");
        for (int i = 0; i < n.getChildCount(); i++) walk(n.getChild(i), depth + 1, sb);
    }
}
